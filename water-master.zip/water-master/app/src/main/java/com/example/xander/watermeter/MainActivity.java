package com.example.xander.watermeter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class MainActivity extends AppCompatActivity {

    long BackPress;

    // Write a message to the database
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("Water Usage Data");

    Cells cells = new Cells();

    private View.OnClickListener button_listener = new View.OnClickListener() {
        public void onClick(View v) {

            EditText textbox1 = (EditText) findViewById(R.id.textBox1);
            EditText textbox2 = (EditText) findViewById(R.id.textBox2);

            String username = textbox1.getText().toString();
            String password = textbox2.getText().toString();
            String mess_title = "Mobile Water Meter";

            if (username.isEmpty() && password.isEmpty()) {
                cells.MessageBox("Kindly input username and password first.", mess_title, MainActivity.this);
            } else if (username.isEmpty()) {
                cells.MessageBox("Kindly enter your username.", mess_title, MainActivity.this);
            } else if (password.isEmpty()) {
                cells.MessageBox("Kindly enter your password.", mess_title, MainActivity.this);
            } else if (username.equals("admin") && password.equals("admin")) {
                ChangeActivity();
            } else {
                cells.MessageBox("Invalid username or password.", mess_title, MainActivity.this);
            }
        }
    };
    private ValueEventListener value_event_listener = new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot dataSnapshot) {
            String value = dataSnapshot.getValue(String.class);
            Toast.makeText(MainActivity.this, value, Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onCancelled(DatabaseError databaseError) {
            Toast.makeText(MainActivity.this, databaseError.toException().toString(), Toast.LENGTH_SHORT).show();
        }
    };

    public void ChangeActivity() {
        cells.changeActivity(this, Main2Activity.class, false);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(button_listener);

        myRef.addValueEventListener(value_event_listener);
        myRef.setValue("Data");
    }

    @Override
    public void onBackPressed() {
        if (BackPress + 1000 > System.currentTimeMillis()) {
            super.onBackPressed();
        } else {
            Toast.makeText(MainActivity.this, "Press once again to exit", Toast.LENGTH_SHORT).show();
        }
        BackPress = System.currentTimeMillis();
    }
}
