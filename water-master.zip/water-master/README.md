# Power
Thesis project repository of Cells, Pauline, Vincent, and Khristelle for Android Application.
